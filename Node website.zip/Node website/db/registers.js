const mongoose = require('mongoose');

// Define Mongoose scheema
const registerSchema= new mongoose.Schema({
    fname: {
        type:String,
        required:true
    },
    lname: {
        type:String,
        required:true
    },
    phone: {
        type:String,
        required:true
    },
    age: {
        type:String,
        required:true
    },
    email: {
        type:String,
        required:true,
        unique:true
    },
    password1: {
        type:String,
        required:true
    },
    password2: {
        type:String,
        required:true
    }
  });

const Register = mongoose.model('Register', registerSchema);

module.exports = Register;