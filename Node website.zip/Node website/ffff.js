require('./models/db');

const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');
const { request } = require('http');
const exphbs = require('express-handlebars');

// var urlencodedParser = bodyParser.urlencoded({ extended: false })
// const GYMRoute = require('./No dele/routes/gym')
const employeeController = require('./controllers/employeeController');
app.use(bodyparser.urlencoded({
    extended: true
}));
mongoose.connect("mongodb://localhost:27017/contact",{useNewUrlParser: true,useUnifiedTopology: true}, (err) => {
    if (!err) console.log('db connected');
    else console.log('db error');
});
// mongoose.connect("mongodb://localhost:27017/Memebers",{useNewUrlParser: true,useUnifiedTopology: true}, (err) => {
//     if (!err) console.log('db connected');
//     else console.log('db error');
// });
const port = 80;
app.use(bodyParser.json())


// Define Mongoose scheema
const contactSchema= new mongoose.Schema({
    name:String,
    phone:String,
    address:String,
    email:String,
    desc:String
  });
const Contact= new mongoose.model("Collection", contactSchema);

// const memberSchema= new mongoose.Schema({
//     name:String,
//     designation:String,
//     email:String,
//     phone:String,
//     age:String
//   });
// const Member= new mongoose.model("Information", memberSchema);

// EXPRESS SPECIFIC STUFF
app.use('/static', express.static('static')) // For serving static files

//PUG SPECIFIC STUFF

app.set('view engine', 'pug') // Set the template engine as pug
app.set('views', path.join(__dirname, 'views')) // Set the views directory

 
// Our pug endpoint

app.get('/', (req, res)=>{
    res.status(200).render('home.pug');
})

app.get("/contact", (req, res)=>{ 
    res.status(200).render('contact.pug');
});
app.post("/contact", urlencodedParser, function(req, res){
    const data = new Contact(req.body);
    data.save().then(()=>{
        res.send("<h1>Thanks for contacting us...Your query has been sent succesfully.</h1>")
    }).catch(()=>{
        res.status(400).send("<h1>Your query has <b>not</b> been sent succesfully.</h1>")
    });
    // res.status(200).render('contact')
})

app.get("/members", (req, res)=>{ 
    res.status(200).render('members.pug');
});

// app.get('/contact', (req, res)=>{
//     const con = "This is the best content on the internet so far so use it wisely"
//     const params = {'title': 'PubG is the best game', "content": con}
//     res.status(200).render('contact.pug', params);
// })

// app.post('/contact', (req, res)=>{
//     name = req.body.name
//     age = req.body.age
//     gender = req.body.gender
//     address = req.body.address
//     more = req.body.more

//     let outputToWrite = `the name of the client is ${name}, ${age} years old, ${gender}, residing at ${address}. More about him/her: ${more}`
//     fs.writeFileSync('output.txt', outputToWrite)
//     const params = {'message': 'Your form has been submitted successfully'}
//     res.status(200).render('contact.pug', params);

// })


app.listen(port, ()=>{
    console.log(`The application started successfully on port ${port}`);
});

app.use('/api/gym', GYMRoute)