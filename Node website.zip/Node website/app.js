require('./db/conn');
const express = require('express')
const bodyParser = require('body-parser')
const bodyparser = require('body-parser');
const app = express()
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');
const { request } = require('http');
const hbs = require("hbs");

const Register = require("./db/registers")

var urlencodedParser = bodyParser.urlencoded({ extended: true })
mongoose.connect("mongodb://localhost:27017/contact", {useNewUrlParser: true}, (err) => {
    if (!err) console.log('db connected');
    else console.log('db error');
});
const port = 80;
app.use(bodyParser.json());
// app.use(express.json());


// Define Mongoose scheema
const contactSchema= new mongoose.Schema({
    name:String,
    phone:String,
    address:String,
    email:String,
    desc:String
  });

const Contact = mongoose.model('Contact', contactSchema);

// EXPRESS SPECIFIC STUFF
app.use('/static', express.static('static')) // For serving static files

//PUG SPECIFIC STUFF
// app.set('view engine', 'hbs'); // Set the template engine as pug
app.set('view engine', 'pug') // Set the template engine as pug
app.set('views', path.join(__dirname, 'views')) // Set the views directory
const partials_path = path.join(__dirname, 'partials');
hbs.registerPartials(partials_path);

// Our pug endpoint

app.get('/', (req, res)=>{
    res.status(200).render('home.pug');
})
app.get('/register', (req, res)=>{
    res.status(200).render('register.pug');
})
app.get('/login', (req, res)=>{
    res.status(200).render('login.pug');
})
app.get("/contact", (req, res)=>{ 
    res.status(200).render('contact.pug');
});
// app.post("/contact", urlencodedParser, function(req, res){
//     const data = new Contact(req.body);
//     data.save().then(()=>{
//         res.send("<h1>Thanks for contacting us...Your query has been sent succesfully.</h1>")
//     }).catch(()=>{
//         res.status(400).send("<h1>Your query has <b>not</b> been sent succesfully.</h1>")
//     });
//     // res.status(200).render('contact')
// })
app.post("/contact", urlencodedParser, (req, res)=>{
    var myData = new Contact(req.body);
    myData.save().then(()=>{
    res.send("<h1>Thanks for contacting us...Your query has been sent succesfully.</h1>")
    }).catch(()=>{
    res.status(400).send("<h1>Your query has <b>not</b> been sent succesfully.</h1>")
    });
})

app.post("/register", urlencodedParser, (req, res)=>{
    // var Data = new Register(req.body);
    // Data.save().then(()=>{
    // res.send("This item has been saved to the database")
    // }).catch(()=>{
    // res.status(400).send("item was not saved to the databse")
    // });
    try{
        const password1 = req.body.password1;
        const password2 = req.body.password2;
        if(password1===password2){
            var data = new Register(req.body);
            data.save().then(()=>{
                res.send("Your Data has been saved to the database. Now Please Login")
                }).catch(()=>{
                    res.status(400).send("Please enter the correct data Or your email should not be same.")
                    });
        }
        else{
            res.send("Password are not matching")
        }
    }
        catch (error) {
            res.status(400).send("Error")
            }
})

app.post("/login", urlencodedParser, async(req, res)=>{
    try{
        const email = req.body.email;
        const password = req.body.password;

        const usermail = await Register.findOne({email:email});

        if(usermail.password1===password){
            // var data = new Register(req.body);
            // data.save().then(()=>{
            //     res.send("Your Data has been saved to the database. Now Please Login")
            //     }).catch(()=>{
            //         res.status(400).send("Please enter the correct data Or your email should not be same.")
            //         });
            res.send("You have logged In")
        }
        else{
            res.send("Invalid login Details")
        }
    }
        catch (error) {
            res.status(400).send("Invalid login Details")
            }
})



// app.get('/contact', (req, res)=>{
//     const con = "This is the best content on the internet so far so use it wisely"
//     const params = {'title': 'PubG is the best game', "content": con}
//     res.status(200).render('contact.pug', params);
// })

// app.post('/contact', (req, res)=>{
//     name = req.body.name
//     age = req.body.age
//     gender = req.body.gender
//     address = req.body.address
//     more = req.body.more

//     let outputToWrite = `the name of the client is ${name}, ${age} years old, ${gender}, residing at ${address}. More about him/her: ${more}`
//     fs.writeFileSync('output.txt', outputToWrite)
//     const params = {'message': 'Your form has been submitted successfully'}
//     res.status(200).render('contact.pug', params);

// })


app.listen(port, ()=>{
    console.log(`The application started successfully on port ${port}`);
});
